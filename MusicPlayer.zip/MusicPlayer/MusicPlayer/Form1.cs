﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MusicPlayer
{
    public partial class Form1 : Form
    {

        Music m = new Music();
        public Form1()
        {
            InitializeComponent();
        }

        // OPEN/BROWSE button
        private void button1_Click(object sender, EventArgs e)
        {

            /*Stream myStream = null;
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.InitialDirectory = "C:\\";
            openFileDialog1.Filter = "MP3 Audio File (*.mp3)|*.mp3|Windows Media Audio File (*.wma)|*.wma|WAV Audio File (*.wav)|*.wav|All Files (*.*)|*.*";
            // openFileDialog1.Filter = "(mp3,wav,mp4,mov,wmv,mpg)|*.mp3;*.wav;*.mp4;*.mov;*.wmv;*.mpg|all files|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = false;
            openFileDialog1.Multiselect = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //try
                //{
                if ((myStream = openFileDialog1.OpenFile()) != null)
                {
                    using (myStream)
                    {
                        string[] fileNameAndPath = openFileDialog1.FileNames;
                        string[] fileName = openFileDialog1.SafeFileNames;
                        for (int i = 0; i < openFileDialog1.SafeFileNames.Count(); i++)
                        {
                            string[]  newLVItem = new string[2];
                            newLVItem[0] = fileName[i];
                            newLVItem[1] = fileNameAndPath[i];

                            ListViewItem lvi = new ListViewItem(newLVItem);
                            //listView1.Items.Add(lvi);

                        }
                    }
                }

                //}
            }*/




            /*openFileDialog1.Filter = "(mp3,wav,mp4,mov,wmv,mpg)|*.mp3;*.wav;*.mp4;*.mov;*.wmv;*.mpg|all files|*.*";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
                txtbxFilepath.Text = openFileDialog1.FileName;*/

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                m.open(openFileDialog1.FileName);
                txtbxFilepath.Text = openFileDialog1.FileName;
            }
        }

        // PAUSE button
        private void button3_Click(object sender, EventArgs e)
        {
            m.pause();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            m.play();
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            m.stop();
            txtbxFilepath.Text = "";
        }
    }
}
