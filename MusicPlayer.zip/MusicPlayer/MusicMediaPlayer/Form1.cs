﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MusicMediaPlayer
{
    public partial class MMPlayer : Form
    {
        public MMPlayer()
        {
            InitializeComponent();
        }

        // To enable dragging of the borderless form
        protected override void WndProc(ref Message m)
        {
            base.WndProc(ref m);
            if (m.Msg == WM_NCHITTEST)
                m.Result = (IntPtr)(HT_CAPTION);
        }

        private const int WM_NCHITTEST = 0x84;
        private const int HT_CLIENT = 0x1;
        private const int HT_CAPTION = 0x2;

        //OPEN/BROWSE
        private void btnLoadFiles_Click(object sender, EventArgs e)
        {
            Stream myStream = null;
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.InitialDirectory = "C:\\";
            openFileDialog1.Filter = "MP3 Audio File (*.mp3)|*.mp3|Windows Media Audio File (*.wma)|*.wma|WAV Audio File (*.wav)|*.wav|All Files (*.*)|*.*";
           // openFileDialog1.Filter = "(mp3,wav,mp4,mov,wmv,mpg)|*.mp3;*.wav;*.mp4;*.mov;*.wmv;*.mpg|all files|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = false;
            openFileDialog1.Multiselect = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //try
                //{
                    if((myStream = openFileDialog1.OpenFile())!= null)
                    {
                        using (myStream)
                        {
                            string[] fileNameAndPath = openFileDialog1.FileNames;
                            string[] fileName = openFileDialog1.SafeFileNames;
                            for(int i = 0; i < openFileDialog1.SafeFileNames.Count(); i++)
                            {
                                string[]  newLVItem = new string[2];
                                newLVItem[0] = fileName[i];
                                newLVItem[1] = fileNameAndPath[i];

                                ListViewItem lvi = new ListViewItem(newLVItem);
                                listView1.Items.Add(lvi);

                            }
                        }
                    }

                //}
            }


        }

        private void btnPlayAll_Click(object sender, EventArgs e)
        {
            WMPLib.IWMPPlaylist playlist = axWindowsMediaPlayer1.playlistCollection.newPlaylist("MyPlayList");
            WMPLib.IWMPMedia media;

            for (int i = 0; i < listView1.Items.Count; i++)

            {
                int ii = 1;
                media = axWindowsMediaPlayer1.newMedia(listView1.Items[i].SubItems[ii].Text);
                playlist.appendItem(media);
                ii++;

                axWindowsMediaPlayer1.currentPlaylist = playlist;
                axWindowsMediaPlayer1.Ctlcontrols.play();
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listView1_DoubleClick(object sender, EventArgs e)
        {
            string selected = listView1.FocusedItem.SubItems[1].Text;
            axWindowsMediaPlayer1.URL = @selected;
        }

        private void axWindowsMediaPlayer1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
